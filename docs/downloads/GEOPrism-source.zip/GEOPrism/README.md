# GEOPrism

A clearer view of gene expression.

## Run locally

Open GEOPrism.Rproj in RStudio, or set your R working directory to this folder.
In the R console, run:

```r
source("install_packages.R")
shiny::runApp()
```

Internet access is required for package installation and GEO downloads.
Built-in gene annotation supports GPL570 and GPL6244. Other platforms do not
have built-in gene mapping/PCA. No normalization or log transformation is added.
Licensed under Apache License 2.0; see LICENSE.
This app-only download omits the full repository development assets.
See the included guide for methods, export scope, and troubleshooting.
R runtime verification is still required for this presentation release.
